<table class="table table-bordered table-sm">
    <thead class="thead-dark">
    <tr>
        <th scope="col" class="text-center">#</th>
        <th scope="col" class="text-center">ID</th>
        <th scope="col" class="text-center">Ngoại hiệu</th>
        <th scope="col" class="text-center">Proxy</th>
    </tr>
    </thead>
    <tbody>
    @foreach ($accounts as $key => $account)
    <tr>
        <td class="text-center">{{ $key + 1 }}</td>
        <td class="text-center">{{ $account->account_id }}</td>
        <td class="text-center">{{ $account->account_name }}</td>
        <td class="text-center">Assign proxy</td>
    </tr>
    @endforeach
    </tbody>
</table>
