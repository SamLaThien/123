@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row">
            <h4>Danh sách nhiệm vụ</h4>
        </div>
        <div class="row">
            <table class="table table-bordered table-summary">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">Tổng số nhiệm vụ đã nhận</th>
                        <th scope="col">Đã Làm</th>
                        <th scope="col">Đã Hủy</th>
                        <th scope="col">Tổng Cống Hiến</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>{{ \Redis::get(now()->format('Ymd') . '_nv_count') }}</th>
                        <td>{{ \Redis::get(now()->format('Ymd') . '_nv_finish') }}</th>
                        <td>{{ \Redis::get(now()->format('Ymd') . '_nv_cancel') }}</th>
                        <td>{{ \Redis::get(now()->format('Ymd') . '_nv_dch') }}</th>
                    </tr>
            </table>
        </div>
    </div>
    <hr>
    @include('nvd._account_list', ['accounts' => $accounts])
@endsection

<style>
    table.table-summary th, table.table-summary th {
        width: 20%;
    }
    h4.no-proxy {
        margin-top: 56px;
    }

    table.has-proxy-list thead th,
    table.has-proxy-list td {
        text-align: center;
        vertical-align: middle;
    }

    table.has-proxy-list tr td:nth-child(1) {
        width: 3%;
        text-align: center;
    }

    table.has-proxy-list tr td:nth-child(2)  {
        width: 15%;
        text-align: center;
    }

    table.has-proxy-list tr td:nth-child(4),
    table.has-proxy-list tr td:nth-child(5) {
        width: 8%;
        text-align: center;
        font-size: 13px;
    }

    table.has-proxy-list tr td:nth-child(3) {
        width: 40%;
    }

    table.has-proxy-list tr td:nth-child(6) {
        width: 15%;
    }

    .acc_name {
        font-size: 12px;
    }

</style>
