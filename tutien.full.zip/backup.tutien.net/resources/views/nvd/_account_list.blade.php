
<table class="table table-bordered table-sm has-proxy-list">
    <thead class="thead-dark">
    <tr>
        <th scope="col">#</th>
        <th scope="col">ID</th>
        <th scope="col">Nhiệm vụ</th>
        <th scope="col">Nhận lúc</th>
        <th scope="col">Phải trả lúc</th>
        <th scope="col">Cập nhật</th>
    </tr>
    </thead>
    <tbody>
    @foreach ($accounts as $key => $account)
        @php
            $task = $account->task;
        @endphp
        <tr class="{{$task && $task->expire_at && $task->expire_at->lt(\Carbon\Carbon::now()) ? 'table-danger' : '' }}">
            <td>{{ $key + 1 }}</td>
            <td>
                <div class="d-flex flex-column">
                    @php
                        $progress = $account->progress;
                        $progressTxt = '';
                        if (strpos($progress, 'Tầng')) {
                            $progress = explode('Tầng', $progress)[0];
                            $progress = trim($progress);
                        } elseif (strpos($progress, 'Viên')) {
                            $progress = explode('Viên', $progress)[0];
                            $progress = trim($progress);
                        }
                    @endphp
                    <span>{{ $account->account_name }}</span>
                    <a href="https://tutien.net/member/{{ $account->account_id }}" class="acc_name" target="_blank">
                        {{ $account->account_id }} (<small>{{ $progress }}</small>)
                    </a>
                </div>
            </td>
            @if ($task)
                <td>
                    @if ($task->tcv_task_id)
                        {{ $task->description }}
                    @else
                        <div class="d-flex flex-column small font-italic text-muted">
                            <span>Nhận nhiệm vụ tiếp theo lúc <b>{{ $task && $task->next_task_at ? $task->next_task_at->format('H:i d/m') : '' }}</b></span>
                        </div>
                    @endif
                </td>
                <td>{{ $task->started_at ? $task->started_at->format('H:i d/m') : '' }}</td>
                <td>{{ $task->expire_at ? $task->expire_at->format('H:i d/m') : ''}}</td>
                <td>
                    <a class="btn-task btn btn-outline-dark btn-sm" href="/nvd/{{ $account->id }}/update">Cập nhật</a>
                    @if ($task->tcv_task_id)
		            <a class="btn-task btn btn-outline-danger btn-sm" href="/accounts/{{ $account->id }}/cancel_task">Hủy</a>
                    <a class="btn-task btn btn-outline-success btn-sm" href="/accounts/{{ $account->id }}/resolve_task">Trả</a>
                    @endif
        		    <a class="btn-task btn btn-outline-info btn-sm" href="/accounts/{{ $account->id }}/update_task">Nhận</a>
                </td>
            @else
                <td class="text-center" colspan="3">
                    <div class="d-flex flex-column small font-italic text-muted">
                        <span>Nhận nhiệm vụ tiếp theo lúc <b>{{ $task && $task->next_task_at ? $task->next_task_at->format('H:i d/m') : '' }}</b></span>
                    </div>
                </td>
                <td>
                    <a class="btn-task btn btn-outline-dark btn-sm" href="/nvd/{{ $account->id }}/update">Cập nhật</a>
                    <a class="btn-task btn btn-outline-info btn-sm" href="/accounts/{{ $account->id }}/update_task">Nhận</a>
                </td>
            @endif
        </tr>
    @endforeach
    </tbody>
</table>
<style>
    .btn-task.btn-outline-success {
        margin-left: 6px;
    }

    .card-header {
        color: #0c5460 !important;
        background-color: #d1ecf1 !important;;
        border-color: #bee5eb !important;;
    }
</style>
