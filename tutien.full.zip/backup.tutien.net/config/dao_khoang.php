<?php
return [
    // 18 => "Băng Hỏa Ngọc",
    // 60 => "Cố Thần Đan",
    // 15 => "Hòa Thị Bích",
    // 42 => "Ngọc Giản Truyền Công",
    // 30503 => "Ngọc Tuyết Linh Sâm",
    // 6898 => "Kim Thủ Chỉ",
    // 78 => "Nhân Sâm Vạn Năm",

    // 63 => "Anh Tâm Thảo",
    // 103 => "Huyết Tinh Thảo",
    // 24 => "Hóa Long Thảo",
    // 65 => "Hóa Nguyên Thảo",
    // 30497 => "Hợp Nguyên Thảo",
    // 25 => "Ngọc Tủy Chi",
    // 7906 => "Luyện Thần Thảo",
    // 33 => "Thiên Nguyên Thảo",
    // 32 => "Trích Tinh Thảo",
    // 23 => "Uẩn Kim Thảo",
    // 33204 => "Đại Linh Thảo",
    // 26 => "Thiên Linh Quả",

    // 53 => "Ngọc Tủy Linh Nhũ CP",
    // 50 => "Ngọc Tủy Linh Nhũ HP",
    // 52 => "Ngọc Tủy Linh Nhũ THP",
    // 51 => "Ngọc Tủy Linh Nhũ TP",
    76 => "Linh Thạch CP",
    // 21 => "Linh Thạch HP",
    61 => "Linh Thạch THP",
    // 39 => "Linh Thạch TP",
    // 56 => "Linh Tuyền",


    // 41651 => "Huyền Âm Băng Liên",
    // 30446 => "Hồi Huyết Đan",
    // 40420 => "Bái Thiếp",
    // 57 => "Kim Thuổng",

    // 8 => "Hoàng Kim Lệnh",
    // 10152 => "Hỏa Ngọc Châu",
    // 70 => "Hộ Linh Trận",
    // 10154 => "Sa Ngọc Châu",
    // 10153 => "Thải Ngọc Châu",
    // 32002 => "Thời Gian Chi Thủy",
    // 10155 => "Tán Lôi Trận",
    // 6853 => "Dạ Minh Châu",
    // 11 => "Đê Giai Thuẫn",
    // 34 => "Thanh Tâm Đan",


    // 11687 => "La Bàn",
    // 11689 => "Quy Giáp",

    // 8080 => "Thiên Kiếm Lệnh",

    // 67 => "Thiên Địa Lô",

    32180 => "Túi Phân Bón",
    // 34340 => "Túi Sủng Vật",
    34348 => "Túi Thức Ăn",
    // 12 => "Túi Trữ Vật",
    // 2131 => "Tẩy Cốt Đan",
    // 19 => "Tụ Bảo Bài",
    // 11 => "Đê Giai Thuẫn",
];
