<?php

return [
    'list' => [
        ['username' => 'use123', 'password' => 'pass', 'host' => 'ip', 'port' => 49412],
    ]
];
