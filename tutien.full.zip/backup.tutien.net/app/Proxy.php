<?php

namespace App;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

/**
 * @property string host
 * @property string port
 * @property string username
 * @property string password
 * @property string type
 * @property string real_ip
 * @property int provider
 * @property-read Carbon|null available_at
 * @property-read int failed_count
 */
class Proxy extends Model
{
    protected $fillable = [
        'host',
        'port',
        'username',
        'password',
        'type',
        'real_ip',
        'provider',
        'user_id',
        'available_at',
        'failed_count',
    ];

    protected $dates = ['available_at'];

    public function getIsAvailableAttribute()
    {
        return !$this->available_at || $this->available_at->lt(Carbon::now());
    }

    public function accounts()
    {
        return $this->belongsToMany(Account::class);
    }
}
