<?php

namespace App;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

/**
 * @property-read int account_id
 * @property-read int type
 * @property-read string description
 * @property-read Carbon started_at
 * @property-read Carbon expire_at
 * @property-read Carbon next_task_at
 * @property-read Carbon finished_at
 * @property-read string tcv_task_id
 * @property-read Account|null account
 */
class Task extends Model
{
    protected $fillable = [
        'account_id',
        'type',
        'description',
        'tcv_task_id',
        'started_at',
        'expire_at',
        'finished_at',
        'next_task_at',
    ];

    protected $dates = ['started_at', 'expire_at', 'finished_at', 'next_task_at'];

    public function account()
    {
        return $this->belongsTo(Account::class);
    }

    public function ott()
    {
        return $this->hasOne(Ott::class);
    }
}
