<?php

namespace App\Jobs;

use App\Account;
use App\Services\AccountService;
use App\Services\TaskService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class ThanThu implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /** @var Account */
    protected $account;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct(Account $account)
    {
        $this->account = $account;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        /** @var AccountService $accountService */
        $accountService = app(AccountService::class);

        /** @var TaskService $taskService */
        $taskService = app(TaskService::class);

        $accountService->chuyenBaiThiep($this->account);
        sleep(2);
        $taskService->baiPhongThanThu($this->account);
        sleep(2);
        $taskService->finishTask($this->account->task);
    }
}
