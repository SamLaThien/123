<?php

namespace App\Jobs;

use App\Services\TaskService;
use App\Task;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Support\Facades\Cache;

class ResolveTask implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /** @var Task */
    protected $task;

    /** @var TaskService */
    protected $taskService;

    protected $check;

    /**
     * Create a new job instance.
     *
     * @param Task $task
     * @param bool $check
     */
    public function __construct(Task $task, bool $check = true)
    {
        $this->task = $task;
        $this->check = $check;
        $this->taskService = app(TaskService::class);
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $this->taskService->resolveTask($this->task);
    }
}
