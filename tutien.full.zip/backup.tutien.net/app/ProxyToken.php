<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property string token
 * @property int type
 * @property User user
 */
class ProxyToken extends Model
{
    protected $fillable = ['token', 'type', 'user_id'];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
