<?php

namespace App\Console\Commands\In;

use Illuminate\Console\Command;
use App\Account;
use App\Proxy;
use App\Services\AccountService;
use Ixudra\Curl\Facades\Curl;
use GuzzleHttp\Client;
use GuzzleHttp\Psr7\Request;

class Tsv extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'tcv:mo-tsv {accountId} {soLuong=0}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Mo tui sung vat';

    protected $accountService;
    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(AccountService $accountService)
    {
        parent::__construct();
        $this->accountService = $accountService;
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $accountId = $this->argument('accountId');
        $soLuong = $this->argument('soLuong');
        $account = Account::where("account_id", $accountId)->first();
        if (!$account) {
            $this->warn("Không tìm thấy account!");
            return;
        }

        if ($soLuong == 0) {
            $this->warn("Số lượng không đúng!");
            return;
        }


        $this->info("Mở tsv trên account: " . $accountId);
        $ok = $this->accountService->chuyenDo($account, 34340, $soLuong);
        if ($ok == 1) {
            $this->info("  => Chuyển thành công " . $soLuong . " tsv cho " . $accountId);
        } else {
            $this->warn("  => Có lỗi xảy ra. Chuyển tsv không thành công!");
            $this->warn("  => " . $ok);
            return;
        }

        $this->info("  ================================================================= ");
        $soLuong = intval($soLuong);
        for ($i = 0; $i < $soLuong; $i++) {
            $res = $this->moTsv($account);
            sleep(2);
            $this->info("  => " . $res);
        }
        $this->info("  =============================== XONG ================================== ");
    }

    public function moTsv(Account $account)
    {
        $client = new Client();
        // $proxies = config('dp_proxies.list');
        $proxy = Arr::random($proxies);
        // $proxyArr = ['http://', $proxy->username, ':', $proxy->password, '@',  $proxy->host, ':', $proxy->port];
        // $proxyOption = ['proxy' => implode("", $proxyArr)];
        $headers = [
            'authority' => 'tutien.net',
            'sec-ch-ua' => '" Not A;Brand";v="99", "Chromium";v="96", "Google Chrome";v="96"',
            'accept' => '*/*',
            'content-type' => 'application/x-www-form-urlencoded; charset=UTF-8',
            'x-requested-with' => 'XMLHttpRequest',
            'sec-ch-ua-mobile' => '?0',
            'user-agent' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36',
            'sec-ch-ua-platform' => '"macOS"',
            'origin' => 'https://tutien.net',
            'sec-fetch-site' => 'same-origin',
            'sec-fetch-mode' => 'cors',
            'sec-fetch-dest' => 'empty',
            'referer' => 'https://tutien.net/account/tu_luyen/tien_phu/',
            'accept-language' => 'en-US,en;q=0.9,vi;q=0.8',
            'cookie' => $account->cookie,
        ];
        $body = 'btnChoAn=1&pet_id=23581';
        $request = new Request('POST', 'https://tutien.net/account/tu_luyen/tien_phu/', $headers, $body);
        $res = $client->sendAsync($request)->wait();
        return $res->getBody();
    }
}


// curl 'https://tutien.net/account/tu_luyen/tien_phu/' \
//   -H 'authority: tutien.net' \
//   -H 'sec-ch-ua: " Not A;Brand";v="99", "Chromium";v="96", "Google Chrome";v="96"' \
//   -H 'accept: */*' \
//   -H 'content-type: application/x-www-form-urlencoded; charset=UTF-8' \
//   -H 'x-requested-with: XMLHttpRequest' \
//   -H 'sec-ch-ua-mobile: ?0' \
//   -H 'user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36' \
//   -H 'sec-ch-ua-platform: "macOS"' \
//   -H 'origin: https://tutien.net' \
//   -H 'sec-fetch-site: same-origin' \
//   -H 'sec-fetch-mode: cors' \
//   -H 'sec-fetch-dest: empty' \
//   -H 'referer: https://tutien.net/account/tu_luyen/tien_phu/' \
//   -H 'accept-language: en-US,en;q=0.9,vi;q=0.8' \
//   -H 'cookie: USER=7WhGCiRxIgBR%3AXSgXPQjZ%2F%2B3QYMSGStoZ6g5IH80ZraYxFUgcCoUdJLB0; PHPSESSID=ij1upq36ncmv2i66fjp3bnihqs; reada=12' \
//   --data-raw 'btnChoAn=1&pet_id=23581' \
//   --compressed
