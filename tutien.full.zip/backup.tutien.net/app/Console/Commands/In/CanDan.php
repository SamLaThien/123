<?php

namespace App\Console\Commands\In;

use Illuminate\Console\Command;

class CanDan extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'tcv:can-dan';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Can dan 1 acc voi so luong co dinh';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        return 0;
    }
}
