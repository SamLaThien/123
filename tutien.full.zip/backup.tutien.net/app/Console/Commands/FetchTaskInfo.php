<?php

namespace App\Console\Commands;

use App\Account;
use App\Jobs\FetchTaskDescription;
use App\Task;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Cache;

class FetchTaskInfo extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'truyencv:fetch-task-info';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Fetch task info';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        taskLog("==================== GETTING TASK INFORMATION ====================");
        $accounts = Account::whereNotNull('cookie')->where("is_nvd", 1)->get();
        $now = Carbon::now();
        foreach ($accounts as $account) {
            /** @var Task $task */
            $task = $account->task;

            if (!$task || !!$task->description || !$task->next_task_at || $task->next_task_at->lt($now)) {
                FetchTaskDescription::dispatch($account)->onQueue('nvd');
            }
        }
    }
}
