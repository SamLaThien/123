<?php

namespace App\Console\Commands;

use App\Account;
use App\Inventory;
use Illuminate\Console\Command;
use Ixudra\Curl\Facades\Curl;

class TangQuaEvent extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'tutien:tang-qua-event';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Tự động tặng quà event';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $inventories = Inventory::where('item_id', 12)->where('amount', '!=', 0)->with('account')->get();
        foreach ($inventories as $inventory) {
            $account = $inventory->account;
            $amount = $inventory->amount;
            for ($i = 0; $i < $amount; $i++) {
                $this->tangQua($account);
                sleep(5);
            }
        }
    }

    private function tangQua(Account $account) 
    {
        $res = Curl::to('https://tutien.net/member/349118/')
            ->withHeader('authority: tutien.net')
            ->withHeader('accept: */*')
            ->withHeader('accept-language: en-US,en;q=0.9,vi;q=0.8')
            ->withHeader('content-type: application/x-www-form-urlencoded; charset=UTF-8')
            ->withHeader($account->cookie)
            ->withHeader('origin: https://tutien.net')
            ->withHeader('referer: https://tutien.net/member/349118')
            ->withHeader('sec-ch-ua: "Chromium";v="106", "Google Chrome";v="106", "Not;A=Brand";v="99"')
            ->withHeader('sec-ch-ua-mobile: ?0')
            ->withHeader('sec-ch-ua-platform: "Linux"')
            ->withHeader('sec-fetch-dest: empty')
            ->withHeader('sec-fetch-mode: cors')
            ->withHeader('sec-fetch-site: same-origin')
            ->withHeader('user-agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36')
            ->withHeader('x-requested-with: XMLHttpRequest')
            ->withData([
                'btntangHoa' => 1,
                'member' => 349118,
            ])
            ->returnResponseObject()
	    ->post();
	$this->info($res->content);
    }
}
