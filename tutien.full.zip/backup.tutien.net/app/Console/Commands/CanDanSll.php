<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Services\DotPhaService;
use App\Events\CanDanMessage;
use Redis;
use App\Account;

class CanDanSll extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'tutien:can-dan-sll {accountId} {danDuoc=tcd} {isDt=0}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Can dan cho nhieu ID toi VM';

    protected $service;
    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(DotPhaService $dp)
    {
        $this->service = $dp;
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $accountId = $this->argument('accountId');
        $danDuoc = $this->argument('danDuoc');
        $isDt = $this->argument('isDt');

        if (Redis::exists('dang_can_dan_' . $accountId)) {
            debug($accountId . ' - Đang cắn đan - skip');
            return;
        }

        Redis::set('dang_can_dan_' . $accountId, 1, 'EX', 10*60); // 10 min
        $count = 0;
        $account = Account::find($accountId);
        while (strpos($account->progress, 'Viên Mãn') === false && $count <= 10 && Redis::exists('dang_can_dan_' . $accountId)) {
            CanDanMessage::dispatch($account, '[Cắn Đan]' . $account->account_name . ' - ' . $account->progress);
            $this->service->canDan($account, $danDuoc, ['vatphamphutro' => []], $isDt);
            $count++;
            sleep(5);
        }
        Redis::del('dang_can_dan_' . $accountId);
    }
}
