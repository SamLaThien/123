<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Account;
use App\Services\AccountService;
use App\Services\DotPhaService;

class AutoCanDan extends Command
{
    const ID_DGT = 11;
    const ID_TLC = 17;
    const ID_THANH = 34;
    
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'tutien:auto-can-dan';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Auto can dan';

    protected $accountService;
    protected $dotPhaService;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(AccountService $accountService, DotPhaService $dotPhaService)
    {
        parent::__construct();
        $this->accountService = $accountService;
        $this->dotPhaService = $dotPhaService;
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        $accounts = Account::select(['id', 'account_id', 'account_name', 'cookie', 'progress', 'progress_change'])
	    ->whereRaw('cast(progress_change as signed) > 80')
            //->where('progress_change', '!=', '100')
            ->where('progress', 'not like', '%Viên Mãn%')
            ->orderBy('progress_change', 'desc')
            ->limit(50)
	    ->get();
        $total = $accounts->count();
        foreach ($accounts as $key => $account) {
            $buff = ['vatphamphutro' => []];
            $progress = $account->progress;
            $message = ['[', $key+1, ' / ', $total, '] ', $account->account_name, ' ', $account->progress];
            $this->info(implode('', $message));
            
            if (strpos($progress, "Luyện Khí") !== false) {
                // if (strpos($progress, 'Viên Mãn' !== false)) {
                //     $buff['vatphamphutro'] = [self::ID_DGT];
                // }

                $this->dotPhaService->canDan($account, 'tcd', $buff);
            } else if (strpos($progress, "Trúc Cơ") !== false) {
                // if (strpos($progress, 'Viên Mãn' !== false)) {
                //     $buff['vatphamphutro'] = [self::ID_DGT, self::ID_TLC];
                // }

                $this->dotPhaService->canDan($account, 'bnd', $buff);
            } else if (strpos($progress, "Kim Đan") !== false || strpos($progress, " Anh") !== false) {
                // if (strpos($progress, 'Viên Mãn' !== false)) {
                //     $buff['vatphamphutro'] = [self::ID_DGT, self::ID_TLC, self::ID_THANH];
                // }
                $this->dotPhaService->canDan($account, 'bad', $buff);
            } else {
                continue;
            }
            sleep(2);
        }
    }
}
