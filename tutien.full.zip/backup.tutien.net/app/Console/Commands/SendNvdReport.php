<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Ixudra\Curl\Facades\Curl;
use Redis;

class SendNvdReport extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'tutien:send-nvd-report';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send NVD report';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $now = now();
        $message = "============= REPORT NVD: " . $now->toDateTimeString() . " ==========";
        $countNvd = Redis::get(now()->format('Ymd') . '_nv_count');
        $finishNvd = Redis::get(now()->format('Ymd') . '_nv_finish');
        $cancelNvd = Redis::get(now()->format('Ymd') . '_nv_cancel');
        $dchNvd = Redis::get(now()->format('Ymd') . '_nv_dch');

        $message .= "\nĐã nhận: " . $countNvd . ' nhiệm vụ';
        $message .= "\nĐã hoàn thành: " . $finishNvd . ' nhiệm vụ';
        $message .= "\nĐã hủy: " . $cancelNvd . ' nhiệm vụ';
        $message .= "\nĐiểm cống hiến nhận được: " . $dchNvd . ' điểm cống hiến';
        $message .= "\n==================== END REPORT ====================";

        $toId = '98455';
        Curl::to('https://tutien.net/index.php')
            ->withHeader('authority: tutien.net')
            ->withHeader('accept: */*')
            ->withHeader('accept-language: en-US,en;q=0.9')
            ->withHeader('content-type: application/x-www-form-urlencoded; charset=UTF-8')
            ->withHeader('cookie: USER=rJ%2FheR9OaHLs%3AFZywf%2BAsXOVMfxc%2F6qaZntCAH4N4ctmsfyj8qhxjqP3f; PHPSESSID=u39111oj7ikupn7v4acntce31b; reada=123')
            ->withHeader('origin: https://tutien.net')
            ->withHeader('referer: https://tutien.net/member/' . $toId)
            ->withHeader('sec-ch-ua: " Not A;Brand";v="99", "Chromium";v="102", "Google Chrome";v="102"')
            ->withHeader('sec-ch-ua-mobile: ?0')
            ->withHeader('sec-ch-ua-platform: "Linux"')
            ->withHeader('sec-fetch-dest: empty')
            ->withHeader('sec-fetch-mode: cors')
            ->withHeader('sec-fetch-site: same-origin')
            ->withHeader('user-agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36')
            ->withHeader('x-requested-with: XMLHttpRequest')
            ->withData([
                'btnMemberComment' => 1,
                'media_id' => $toId,
                'num' => 5,
                'txtContent' => $message,
                'parent' => '',
            ])
            ->post();
    }
}
