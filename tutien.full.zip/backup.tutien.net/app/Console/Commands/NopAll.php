<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Account;
use App\Services\AccountService;

class NopAll extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'tutien:nop-all';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Nộp đồ từ các account có is_nopdo = true';

    protected $accountService;
    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(AccountService $accountService)
    {
        parent::__construct();
        $this->accountService = $accountService;
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $accounts = Account::where('is_nopdo', 1)->get();
        $count = $accounts->count();
        foreach ($accounts as $key => $account) {
            $this->info("[" . ($key+1) . "/" . $count . "] " . $account->account_name);
            $this->accountService->checkRuong($account, false);
        }
    }
}
