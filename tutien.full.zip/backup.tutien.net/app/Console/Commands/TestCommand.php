<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Account;

class TestCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'tutien:export';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
    	$accounts = Account::whereNotNull('cookie')->orderBy('progress')->get(['account_id', 'cookie', 'progress']);
        foreach ($accounts as $account) {
            $cookie = $account->cookie;
            $cookieArr = explode('; ', $cookie);
            $userCookie = '';
            foreach ($cookieArr as $index => $item) {
                if (strpos($item, 'USER') !== false) {
                    $account->cookie = str_replace('cookie: ', '', $item);
                    continue;
                }
            }
	}

	foreach ($accounts as $account) {
	    $this->info($account->account_id . ' - ' . $account->cookie . ' - ' . $account->progress);
	}
    }
}
