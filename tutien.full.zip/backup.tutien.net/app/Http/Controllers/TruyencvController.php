<?php

namespace App\Http\Controllers;

use App\Account;
//use App\Jobs\QuayVqmm;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Artisan;
//use Ixudra\Curl\Facades\Curl;
//use Carbon\Carbon;
//use voku\helper\HtmlDomParser;
use Redis;
use App\Services\ShellCommand;
use App\Services\CommandService;
use App\Services\AccountService;

class TruyencvController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    public function vqmm()
    {
	    $accounts = auth()->user()
		    ->accounts()
		    ->where("tai_san", ">", 10000)
		    ->where('progress', 'like', '% Hư%')
		    ->where('is_nvd', 1)
		    ->orderBy("tai_san")
		    ->limit(200)
		    ->get();
        return view("vqmm")->with(compact("accounts"));
    }

    public function quay(Request $request)
    {
        $accounts = $request->get('accs', []);
	    $accountIds = Arr::pluck($accounts, 'id');
        if (count($accountIds) == 0) {
	    Redis::set('cookie_vqmm', json_encode([]), 'EX', 30*60);
  	    sleep(2);
            $res = ShellCommand::execute('PM2_HOME=/var/www/.pm2 pm2 stop all');
            //$res = shell_exec('PM2_HOME=/var/www/.pm2 pm2 stop all');
            debug($res);
            return response()->json("Done");
        }
        $cookies = Account::whereIn('id', $accountIds)->get('cookie')->pluck('cookie')->toArray();

        $arr = [];
        foreach ($cookies as $cookie) {
            $cookieArr = explode('; ', $cookie);
            $userCookie = '';
            foreach ($cookieArr as $index => $item) {
                if (strpos($item, 'USER') !== false) {
                    $arr[] = str_replace('cookie: ', '', $item);
                    continue;
                }
            }
        }

        Redis::set('cookie_vqmm', json_encode($arr), 'EX', 30*60); // expire after 1 hour
        sleep(2);
        $res = ShellCommand::execute('PM2_HOME=/var/www/.pm2 pm2 restart all');
        //$res = shell_exec('PM2_HOME=/var/www/.pm2 pm2 restart all');
        debug($res);
        return response()->json("Done");
    }

    public function canDanSll(Request $request)
    {
        $accountId = $request->get('accountId');
        $danDuocName = $request->get('danDuocName');
        $isDt = $request->get('is_dt', 0);

        // dispatch(function () {
        //     Artisan::call("tutien:can-dan-sll " . $accountId . " " . $danDuocName);
        // });
        //$res = ShellCommand::execute("php /home/pham.van.doanh/tutien.net/artisan tutien:can-dan-sll " . $accountId . " " . $danDuocName . "  >> /dev/null 2>&1");
        //debug($res);
        $service = app(CommandService::class);
        $service->runBackgroundCommand("tutien:can-dan-sll " . $accountId . " " . $danDuocName . " " . $isDt);
        return response()->json("Done");
    }

    public function moRuong(Account $account)
    {
        $res = app(AccountService::class)->moRuong($account);
        return response()->json(['result' => $res]);
    }

    public function openEventItem(Account $account)
    {
        $res = app(AccountService::class)->openEventItem($account);
        return response()->json(['result' => $res['data']]);
    }
}

