<?php

namespace App\Http\Controllers;

use App\Account;
use App\Jobs\FetchTaskDescription;
use App\Task;
use App\User;
use Illuminate\Http\Request;

class TaskController extends Controller
{
    public function index()
    {
//        $user = auth()->user();
//        $accounts = $user->accounts->load(['proxies', 'task']);
//        $hasProxy = collect($accounts->filter(function ($account) {
//            return $account->proxies->count();
//        })->values());
//
//        $noProxy = collect($accounts->filter(function ($account) {
//            return !$account->proxies->count();
//        })->values());
//
//        return view('nvd.index')->with(compact('hasProxy', 'noProxy'));

        $user = auth()->user();
        $accounts = $user->accounts()->where('is_nvd', 1)->get();
        $accounts->load(['task' => function ($query) {
            return $query->orderBy("description", "desc");
        }]);
//        $tasks = Task::whereHas('account', function ($query) use ($user) {
//                $query->where('user_id', $user->id)->whereIsNvd(1);
//            })
//            ->orderBy('type', 'desc')
//            ->orderBy('description', 'desc')
//            ->orderBy('next_task_at', 'asc')
//            ->with('account')
//            ->get();
        return view('nvd.index')->with(compact('accounts'));
    }

    public function fetchTask()
    {
        $accounts = auth()->user()->accounts()->whereNotNull('cookie')->get();
        foreach ($accounts as $account) {
            if (!$account->task) {
                FetchTaskDescription::dispatch($account);
            }
        }

        return redirect()->route('nvd.index');
    }

    public function updateTask(Account $account)
    {
        // FetchTaskDescription::dispatch($account);
        app(\App\Services\TaskService::class)->fetchTaskDescription($account);
        flash('Cập nhật nhiệm vụ cho: ' . $account->account_name . '....')->success()->important();
        return redirect()->route('nvd.index');
    }

    public function doTaskLoto(Task $task) 
    {
	    app(\App\Services\TaskService::class)->resolveTaskLoto($task);
	    flash('Làm nhiệm vụ loto cho: ' . $task->account->account_name . '....')->success()->important();
        return redirect()->route('nvd.index');
    }
}
