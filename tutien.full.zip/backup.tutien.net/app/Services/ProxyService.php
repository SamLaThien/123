<?php

namespace App\Services;

use App\Account;
use App\Proxy;
use Carbon\Carbon;

class ProxyService
{
    const PROXY_TYPE_GOOGLE = 0;
    const PROXY_TYPE_WEBSHARE = 1;
    const PROXY_TYPE_PROXY11 = 2;
    const PROXY_TYPE_FREE = 3;

    const PROXY_101_JSON_URL = 'https://proxy11.com/api/proxy.json?';
    const PROXY_101_TEXT_URL = 'https://proxy11.com/api/proxy.txt?';

    /**
     * @return Proxy
     */
    public function getAvailableProxy()
    {
        return Proxy::whereDoesntHave('accounts')->first();
        // $now = Carbon::now();

        // return Proxy::where(function ($query) use ($now) {
        //         $query->whereNull('available_at')
        //             ->orWhere('available_at', '<', $now);
        //     })
        // ->whereDoesntHave('accounts')
        // ->where('failed_count', '=', 0)
        // ->orderBy('failed_count', 'asc')
        // ->orderBy('available_at', 'asc')
        // ->first();
    }
}
