<?php

namespace App\Services;

use App\Account;
use App\CookieHelper;
use App\Inventory;
// use App\Jobs\AutoAssignProxy;
use App\Jobs\CancelTask;
// use App\Jobs\CheckTaskResult;
use App\Jobs\FetchTaskDescription;
use App\Jobs\GetTask;
// use App\Jobs\ResolveTask;
use App\Jobs\StartLoto;
use App\Jobs\StartMining;
use App\Jobs\ThanThu;
// use App\Jobs\UpdateProxy;
use App\Proxy;
use App\Task;
use App\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Redis;
use Ixudra\Curl\Facades\Curl;
use voku\helper\HtmlDomParser;

class TaskService
{
    const TASK_DAO_KHOANG = 1;
    const TASK_LO_TO = 2;
    const TASK_THAN_THU = 3;
    const TASK_BC = 4;
    const TASK_OTT = 5;
    const TASK_OTHER = 0;

    const TASK_STEP_LK = 1;
    const TASK_STEP_TC = 2;
    const TASK_STEP_KD = 3;
    const TASK_STEP_NA = 4;
    const TASK_STEP_HT = 5;
    const TASK_STEP_LH = 6;
    const TASK_STEP_HOP = 7;
    const TASK_STEP_DT = 8;
    const TASK_STEP_DK = 9;

    const LEVEL_LK = 'Luyện Khí';
    const LEVEL_TC = 'Trúc Cơ';
    const LEVEL_KD = 'Kim Đan';
    const LEVEL_NA = 'Nguyên Anh';
    const LEVEL_HT = 'Hóa Thần';
    const LEVEL_LH = 'Luyện Hư';
    const LEVEL_HOP = 'Hợp Thể';
    const LEVEL_DT = 'Đại Thừa';
    const LEVEL_DK = 'Độ Kiếp';
    const LEVEL_NT = 'Nhân Tiên';

    const BASE_URL = 'https://tutien.net/account/nhiem_vu/';
    const LOTO_URL = 'https://tutien.net/lo-to/';
    const DAO_KHOANG_URL = 'https://tutien.net/account/nhiem_vu/';
    const RUONG_URL = 'https://tutien.net/account/nhiem_vu/';

    const PROXY_TYPE_WEBSHARE = 1;
    const PROXY_TYPE_PROXY11 = 2;
    const PROXY_TYPE_GOOGLE = 0;

    /** @var ProxyService */
    protected $proxyService;

    public function __construct(ProxyService $proxyService)
    {
        $this->proxyService = $proxyService;
    }

    /**
     * @param Account $account
     * @return bool
     */
    public function getNewTask(Account $account): bool
    {
        if ($this->canGetTask($account)) {
            GetTask::dispatch($account)->onQueue('tasks');
            return true;
        }

        return false;
    }

    public function getTask(Account $account)
    {
        if ($account->proxies()->count()) {
            $proxy = $account->proxies()->first();
        } else {
            $proxy = $this->proxyService->getAvailableProxy();
            if (!$proxy) {
                task_error('Cannot find available proxy at current time');
                return;
            }

            $account->proxies()->sync($proxy);
        }

        $response = $this->getBaseCurl(self::BASE_URL, $account->cookie, $account->proxy)
        ->withData([
            'btnNhanNhiemVu' => 1
        ])
        ->withResponseHeaders()
        ->returnResponseObject()
        ->post();

        $content = $response->content;
        $headers = $response->headers;

        if (isset($response->error) && $proxy->provider != 100) {
            $proxy->update(['failed_count' => $proxy->failed_count + 1]);
            $account->proxies()->detach();
            // AutoAssignProxy::dispatch($account->id)->onQueue('proxies');
            return;
        }

        if (empty($headers) && $proxy->provider != 100) {
            $proxy->update(['failed_count' => $proxy->failed_count + 1]);
            $account->proxies()->detach();
            // AutoAssignProxy::dispatch($account->id)->onQueue('proxies');
            return;
        }

        if (empty($headers['set-cookie']) && empty($headers['Set-Cookie'])) {
            return;
        }

        // Update cookie
        $cookie = app(CookieHelper::class)->updateCookie($account->cookie, $headers);
        $newCookie = implode('; ', $cookie);
        $account->update(['cookie' => $newCookie]);

        if ($content == '1') {
            taskLog($account->account_name . ': Get New Task - SUCCESS', $account->user_id);
            if ($account->task) {
                $account->task()->update([
                    'type' => 0,
                    'started_at' => Carbon::now(),
                    'finished_at' => null,
                ]);
            } else {
                $account->task()->create([
                    'type' => 0,
                    'started_at' => Carbon::now(),
                    'finished_at' => null,
                ]);
            }

            $proxy->update(['available_at' => $this->getNextTaskTime($account)]);
            FetchTaskDescription::dispatch($account)->onQueue('tasks');
            return;
        }

        if (strpos($content, 'Đạo hữu chưa trả nhiệm vụ cũ') !== false) {
            taskLog($account->account_name . ': Get New Task - Đạo hữu chưa trả nhiệm vụ cũ');
            FetchTaskDescription::dispatch($account)->onQueue('tasks');
            return;
        }

        if (strpos($content, 'cần chờ') !== false) {
            if ($proxy->provider != 100) {
                $account->proxies()->detach();
                // AutoAssignProxy::dispatch($account->id)->onQueue('proxies');
            }

            $minutes = str_replace('Đạo hữu cần chờ ', '', $content);
            $minutes = (int) str_replace(' phút nữa mới có thể nhận nhiệm vụ mới', '', $minutes);
            taskLog($account->account_name . ': Get New Task - ' . $content);
            $nextTaskAt = Carbon::now()->addMinutes($minutes);

            if ($account->task) {
                $account->task->update([
                    'next_task_at' => $nextTaskAt,
                ]);
            } else {
                $account->task()->create([
                    'next_task_at' => $nextTaskAt,
                    'account_id' => $account->id,
                    'type' => 0,
                    'description' => '',
                    'started_at' => null,
                    'expire_at' => null,
                    'finished_at' => null,
                    'tcv_task_id' => null,
                ]);
            }

            // $proxy->update(['available_at' => now()->addMinutes($minutes)]);
        }

    }

    /**
     * @param Task $task
     * @return bool
     */
    public function resolveTask(Task $task): bool
    {
        if ($task->type === self::TASK_OTHER || !$task->tcv_task_id) {
            return true;
        }


        $taskType = $task->type;
        $account = $task->account;
        if ($taskType == self::TASK_DAO_KHOANG) {
            $this->finishTask($task);
            return true;
        } elseif ($taskType == self::TASK_LO_TO) {
            StartLoto::dispatch($task)->onQueue("tasks");
        } elseif ($taskType === self::TASK_BC) {

        } elseif ($taskType == self::TASK_THAN_THU) {
            ThanThu::dispatch($account)->onQueue("tasks");
        }
        return true;
    }

    /**
     * @param Task $task
     * @param bool $withProxy
     */
    public function finishTask(Task $task, bool $withProxy = true)
    {
        $account = $task->account;
	    $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://tutien.net/account/nhiem_vu/',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => 'btnTraNhiemVu=1&nhiemvu_id=' . $task->tcv_task_id,
        CURLOPT_HTTPHEADER => array(
            'authority: tutien.net',
            'sec-ch-ua: "Chromium";v="92", " Not A;Brand";v="99", "Google Chrome";v="92"',
            'accept: */*',
            'x-requested-with: XMLHttpRequest',
            'sec-ch-ua-mobile: ?0',
            'user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.159 Safari/537.36',
            'content-type: application/x-www-form-urlencoded; charset=UTF-8',
            'origin: https://tutien.net',
            'sec-fetch-site: same-origin',
            'sec-fetch-mode: cors',
            'sec-fetch-dest: empty',
            'referer: https://tutien.net/account/nhiem_vu/',
            'accept-language: en-US,en;q=0.9,vi;q=0.8',
            $account->cookie,
        ),
        ));

        $content = curl_exec($curl);
        curl_close($curl);
        taskLog($task->account->account_name . ': ' . $content);
        if (strpos($content, 'Chúc mừng') !== false) {
            taskLog($task->account->account_name . ': Finish Task - ' . $task->description);
            $task->update([
                'type' => 0,
                'description' => '',
                'started_at' => null,
                'expire_at' => null,
                'finished_at' => null,
                'tcv_task_id' => null,
            ]);
        }
    }


    private function isLotoDenied(Account $account): bool
    {
        return false;
    }

    /**
     * @param Account $account
     * @return bool
     */
    public function fetchTaskDescription(Account $account): bool
    {
        $response = $this->getBaseCurl(self::BASE_URL, $account->cookie, $account->proxy)
            ->withResponseHeaders()
            ->returnResponseObject()
            ->get();

        $content = $response->content;
        $html = HTMLDomParser::str_get_html($content);
        if (gettype($html) == 'boolean') {
            return false;
        }

        $info = $html->find('div[id^="nv_"]');
        if (!$info || $info->length === 0)  {
            if ($account->task) {
                $account->task()->update([
                    'type' => 0,
                    'description' => '',
                    'started_at' => null,
                    'expire_at' => null,
                    'finished_at' => null,
                    'tcv_task_id' => null,
                ]);
            }
            // return false;
        }

        if (is_array($info)) {
            $taskId = str_replace('nv_', '', $info->id[0]);
        } else {
            $taskId = str_replace('nv_', '', $info->id);
        }

        if (is_array($taskId)) {
            $taskId = $taskId[0];
        }

        $infos = $info->find('div');
        $infos = $info->find('div');
        if (!$infos || $infos->length === 0)  {
            return false;
        }

        $taskDescription = $infos[1]->plaintext;
        $taskStartAt = Carbon::createFromFormat('H:i:s - d/m/Y', $infos[3]->plaintext);
        $taskDeadlineAt = Carbon::createFromFormat('H:i:s - d/m/Y', $infos[4]->plaintext);

        $taskType = 0;
        if (strpos($taskDescription, 'Thần Thú') !== false) {
            $taskType = self::TASK_THAN_THU;
        } elseif (strpos($taskDescription, 'lô tô') !== false) {
            $taskType = self::TASK_LO_TO;
        } elseif (strpos($taskDescription, 'đào') !== false) {
            $taskType = self::TASK_DAO_KHOANG;
        } elseif (strpos($taskDescription, 'bí cảnh') !== false) {
            // $taskType = self::TASK_BC;
        } elseif (strpos($taskDescription, 'oẳn tù tì') !== false) {
            $taskType = self::TASK_OTT;
        }

        $nextTaskAt = $this->getNextTaskTime($account, $taskStartAt);
        $data = [
            'description' => $taskDescription,
            'started_at' => $taskStartAt,
            'expire_at' => $taskDeadlineAt,
            'type' => $taskType,
            'tcv_task_id' => $taskId,
            'next_task_at' => $nextTaskAt,
        ];

        if ($account->task) {
            $account->task()->update($data);
        } else {
            $account->task()->create($data);
        }

        if ($taskType == self::TASK_DAO_KHOANG) {
            StartMining::dispatch($account)->onQueue("tasks");
        } elseif ($taskType == self::TASK_LO_TO) {
            StartLoto::dispatch($account->task)->onQueue("tasks");
        } elseif ($taskType === self::TASK_BC) {

        } elseif ($taskType == self::TASK_THAN_THU) {
            ThanThu::dispatch($account)->onQueue("tasks");
        }

        return true;
    }

    /**
     * @param Task $task
     * @return bool
     */
    public function resolveTaskLoto(Task $task)
    {
        $today = Carbon::now()->format('Ymd');
        $account = $task->account;

        $formData = [
            'btnMuaVeLoto' => 1,
            'txtSoLuong' => 10,
        ];
	/*
        if ($account->bang_phai == 'tu-la-ma-dien') {
            $formData = [
                'btnMuaVeLott' => 1,
                'txtSoLuong' => 10,
            ];
	}
	 */
        $response = $this->getBaseCurl(self::LOTO_URL, $account->cookie, $account->proxy)
            ->withData($formData)
            ->withResponseHeaders()
            ->returnResponseObject()
            ->post();

        $content = $response->content;
        if ($content == '1') {
            $this->finishTask($task);
            return true;
        }

        if ($content != '2' && $content != '') {
            if (Cache::has('loto_' . $account->account_id)) {
                $this->finishTask($task);
                return;
            }

            taskLog($account->account_name . ': Hết bạc => Tự động chuyển 2000 bạc', $account->user_id);
            $this->chuyenBac($account, 2000);
            Cache::put('loto_' . $account->account_id, true, 3*60); // 3h * 60p
        }

        return false;
    }

    public function resolveTaskDaoKhoang(Task $task)
    {
        if ($this->isDaoKhoangResolved($task)) {
            $this->finishTask($task);
        }

        return true;
    }

    public function resolveTaskExp(Task $task)
    {
        //$this->finishTask();
        return true;
    }

    /**
     * @param Task $task
     * @return bool
     */
    public function isDaoKhoangResolved(Task $task): bool
    {
        $account = $task->account;
        $response = $this->getBaseCurl('https://tutien.net/account/message/?t=hethong', $account->cookie, $account->proxy)
            ->withResponseHeaders()
            ->returnResponseObject()
            ->get();

        $content = $response->content;
        $status = $this->handleProxyRequest($account, $proxy, $content);
        if (!$status) {
            return false;
        }

        $html = HTMLDomParser::str_get_html($content);
        if (gettype($html) == 'boolean') {
            return false;
        }

        $msgs = $html->find('.comments tr');
        for ($i = 0; $i < $msgs->length; $i ++) {
            $tds = $msgs[$i]->find('td');
            $time = str_replace(' Ngày ', ' ', $tds[0]->plaintext);
            $startAt = $task->started_at;
            $messageTime = Carbon::createFromFormat('H:i d/m/Y', $time);
            $text = $tds[1]->plaintext;
            if ($startAt->lt($messageTime)) {
                if (strpos($text, 'đào được') !== false) {
                    return true;
                }
            }
        }

        return false;
    }


    /**
     * @param Account $account
     * @return bool
     */
    public function canGetTask(Account $account)
    {
        $prevTask = $account->task;
        $now = Carbon::now();

        if (!$prevTask) {
            return true;
	    }

	    if ($prevTask->tcv_task_id == null && $now->gt($prevTask->next_task_at)) {
            return true;
        }

        if ($prevTask->type == self::TASK_OTHER) {
            $this->cancelTask($account);
            return false;
        }

        return false;
    }

    /**
     * @param Account $account
     * @param Carbon|null $time
     * @return Carbon
     */
    public function getNextTaskTime(Account $account, Carbon $time = null): Carbon
    {
        if (strpos($account->progress, self::LEVEL_LK) !== false) {
            return $this->getNextTimeByStep(self::TASK_STEP_LK, $time);
        }

        if (strpos($account->progress, self::LEVEL_TC) !== false) {
            return $this->getNextTimeByStep(self::TASK_STEP_TC, $time);
        }

        if (strpos($account->progress, self::LEVEL_KD) !== false) {
            return $this->getNextTimeByStep(self::TASK_STEP_KD, $time);
        }

        if (strpos($account->progress, self::LEVEL_NA) !== false) {
            return $this->getNextTimeByStep(self::TASK_STEP_NA, $time);
        }

        if (strpos($account->progress, self::LEVEL_HT) !== false) {
            return $this->getNextTimeByStep(self::TASK_STEP_HT, $time);
        }

        if (strpos($account->progress, self::LEVEL_LH) !== false) {
            return $this->getNextTimeByStep(self::TASK_STEP_LH, $time);
        }

        if (strpos($account->progress, self::LEVEL_HOP) !== false) {
            return $this->getNextTimeByStep(self::TASK_STEP_HOP, $time);
        }

        if (strpos($account->progress, self::LEVEL_DT) !== false) {
            return $this->getNextTimeByStep(self::TASK_STEP_DT, $time);
        }

        if (strpos($account->progress, self::LEVEL_DK) !== false) {
            return $this->getNextTimeByStep(self::TASK_STEP_DK, $time);
        }

        if (strpos($account->progress, "Nhân Tiên") !== false) {
            return $this->getNextTimeByStep(self::TASK_STEP_DK + 1, $time);
        }

        if (strpos($account->progress, "Địa Tiên") !== false) {
            return $this->getNextTimeByStep(self::TASK_STEP_DK + 2, $time);
        }

        if (strpos($account->progress, "Thiên Tiên") !== false) {
            return $this->getNextTimeByStep(self::TASK_STEP_DK + 3, $time);
        }

        return Carbon::now()->addDay();
    }

    /**
     * @param int $step
     * @param Carbon|null $time
     * @return Carbon
     */
    private function getNextTimeByStep(int $step, Carbon $time = null): Carbon
    {
        $hours = 24 % $step;
        $minutes = (24.0 / $step) - $hours;
        if ($time) {
            return $time->copy()->addHour($hours)->addMinutes($minutes*60 + 5);
        }

        return Carbon::now()->addHour($hours)->addMinutes($minutes*60 + 5);
    }

    public function cancelTask(Account $account)
    {
        $task = $account->task;
        if ($task->started_at && $task->started_at->diffInMinutes(now()) < 60) {
            return false;
        }

        if (!$task->description) {
            $this->fetchTaskDescription($account);
            return;
        }

        $response = $this->getBaseCurl(self::BASE_URL, $account->cookie, $account->proxies()->first())
            ->withData([
                'btnHuyNhiemVu' => 1,
                'nhiemvu_id' => $task->tcv_task_id,
            ])
            ->withResponseHeaders()
            ->returnResponseObject()
            ->post();

        taskLog($account->account_name . ' - Cancel: ' . $task->description);
        if ($response->content == '1') {
            $account->task->update([
                'type' => 0,
                'description' => '',
                'started_at' => null,
                'expire_at' => null,
                'finished_at' => null,
                'tcv_task_id' => null,
            ]);
        }
    }

    /**
     * @param Account $account
     */
    public function startMining(Account $account)
    {
        $isMining = Cache::has('mining_' . $account->account_id);
        if ($isMining) {
            taskLog($account->account_name . ' - Đang đào khoáng', $account->user_id);
            return;
        }

        $response = $this->getBaseCurl('https://tutien.net/account/tu_luyen/dao_khoang/', $account->cookie, $account->proxy)
            ->withData([
                'btnDaoKhoang' => 1,
                'txtHour' => 6,
                'txtMo' => env('MINE_LOCATION', 2)
            ])
            ->withResponseHeaders()
            ->returnResponseObject()
            ->post();

        $content = $response->content;
        if ($content == 1) {
            Cache::put('mining_' . $account->account_id, true, 6*60); // 6h * 60p
            taskLog($account->account_name . ' - Bắt đầu đào khoáng', $account->user_id);
        } else if (strpos($content, 'Đạo hữu không đủ') !== false) {
            taskLog($account->account_name . ' - Không đủ bạc => chuyển 1500 bạc đào khoáng', $account->user_id);
            $this->chuyenBac($account, 1500);

            sleep(1);
            $response = $this->getBaseCurl('https://tutien.net/account/tu_luyen/dao_khoang/', $account->cookie, $account->proxy)
                ->withData([
                    'btnDaoKhoang' => 1,
                    'txtHour' => 6,
                    'txtMo' => env('MINE_LOCATION', 2)
                ])
                ->withResponseHeaders()
                ->returnResponseObject()
                ->post();

            $content = $response->content;
            if ($content == 1) {
                Cache::put('mining_' . $account->account_id, true, 6*60); // 6h * 60p
                taskLog($account->account_name . ' - Bắt đầu đào khoáng', $account->user_id);
            }
            // StartMining::dispatchNow($account)->onQueue("tasks");
        }

    }

    /**
     * @param User $user
     * @param string $token
     * @param int $type
     * @return bool
     */
    public function fetchTokenList(User $user, string $token, int $type = self::PROXY_TYPE_WEBSHARE): bool
    {
        $proxies = [];
        if ($type == self::PROXY_TYPE_WEBSHARE) {
            $proxies = $this->getWebshareProxy($user, $token);
        } elseif ($type == self::PROXY_TYPE_PROXY11) {
            $proxies = $this->getProxy11Proxy($user, $token);
        }

        foreach ($proxies as $proxy) {
            // UpdateProxy::dispatch($proxy, $user);
        }

        return true;
    }

    /**
     * @param User $user
     * @param string $token
     * @return array
     */
    public function getWebshareProxy(User $user, string $token)
    {
        $response = Curl::to('https://proxy.webshare.io/api/proxy/list/')
            ->withHeader('Authorization: Token ' . $token)
            ->withResponseHeaders()
            ->returnResponseObject()
            ->get();

        $content = $response->content;
        if ($content == '') {
            return [];
        }

        $content = json_decode($content, true);
        $proxies = [];
        foreach ($content['results'] as $proxy) {
            $proxy['host'] = 'p.webshare.io';
            $proxy['port'] = 80;
            $proxy['password'] = $proxy['password'];
            $proxy['provider'] = self::PROXY_TYPE_WEBSHARE;
            $proxy['user_id'] = $user->id;
            $proxies[] = $proxy;
        }

        return $proxies;
    }

    /**
     * @param User $user
     * @param string $token
     * @return array
     */
    public function getProxy11Proxy(User $user, string $token)
    {
        $response = Curl::to('https://proxy11.com/api/proxy.json?key=' . $token)
            ->withHeader('Content-Type: application/json')
            ->withResponseHeaders()
            ->returnResponseObject()
            ->get();

        $content = $response->content;
        if ($content == '') {
            return [];
        }

        $content = json_decode($content, true);
        $proxies = [];
        foreach ($content['data'] as $proxy) {
            $proxy['host'] = $proxy['ip'];
            $proxy['proxy_address'] = $proxy['ip'];
            $proxy['real_ip'] = $proxy['ip'];
            $proxy['provider'] = self::PROXY_TYPE_PROXY11;
            $proxy['user_id'] = $user->id;
            $proxy['type'] = 'http://';
            $proxies[] = $proxy;
        }

        return $proxies;
    }

    /**
     * @param Account $account
     * @param int $amount
     * @return bool|void
     */
    public function chuyenBac(Account $account, int $amount = 0)
    {
        $cookie = env('TU_LA_BANK_COOKIE', null);
        if ($account->bang_phai != 'tu-la-ma-dien') {
            $cookie = env('MY_NHAN_BANK_COOKIE', null);
        }

        if (!$cookie) {
            debug("Please update banks cookie");
            return;
        }

        $url = "https://tutien.net/index.php";
        $to = $account->account_id;
        $response = $this->getBaseCurl($url, $cookie, $account->proxy)
            ->withData([
                'btntangNganLuong' => 1,
                'txtMoney' => $amount,
                'member' => $to
            ])
            ->withResponseHeaders()
            ->returnResponseObject()
            ->post();

        if ($response->status == 200 && $response->content == 1) {
            return true;
        }

        return false;
    }

    public function playOtt(Account $account = null, int $amount = 50)
    {
        $formHash = env('OTT_FORM_HASH');
        $url = 'https://tutien.net/guesspro/';
        $referer = 'https://tutien.net/oan-tu-ti/';

        $random = (int) (microtime(true) * 1000);
        $choice = rand(1, 3);
        $cookie = $account->cookie;

        $response = $this->getBaseCurl($url, $cookie, $account->proxy, $referer)
            ->withData([
                'a' => 'play',
                'userchoice' => $choice,
                'credit' => 50,
                'formhash' => $formHash,
                'random' => $random,
            ])
            ->withResponseHeaders()
            ->returnResponseObject()
            ->get();

        $content = $response->content;
        if ($response->status == 200 && $content && strpos($content, 'userchoice') !== false) {
            return true;
        }

        return false;
    }

    public function checkTaskResult(Account $account)
    {
        $response = $this->getBaseCurl('https://tutien.net/account/message/?t=hethong', $account->cookie, $account->proxy)
            ->withResponseHeaders()
            ->returnResponseObject()
            ->get();

        $content = $response->content;
        $html = HTMLDomParser::str_get_html($content);
        if (gettype($html) == 'boolean') {
            return false;
        }

        $msgs = $html->find('.comments tr');
        for ($i = 0; $i < $msgs->length; $i ++) {
            $tds = $msgs[$i]->find('td');
            $time = str_replace(' Ngày ', ' ', $tds[0]->plaintext);
            $startAt = Carbon::now()->subMinutes(20);
            $messageTime = Carbon::createFromFormat('H:i d/m/Y', $time);
            $text = $tds[1]->plaintext;
            if ($startAt->lt($messageTime)) {
                if (strpos($text, 'may mắn') !== false) {
                    $this->filterReward($account, $text);
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * @param Account $account
     * @param string $srcMessage
     */
    public function filterReward(Account $account, string $srcMessage)
    {
        $type = 'tbdc';
        $message = $account->account_name;
        if (strpos($srcMessage, ' Cao') !== false) {
            $message = $message . ' - Tàng Bảo Đồ Cao';
        } elseif (strpos($srcMessage, ' Tàng Bảo Đồ ') !== false) {
            $message = $message . ' - Tàng Bảo Đồ';
            $type = 'tbd';
        }

        if (strpos($srcMessage, ' Quy G') !== false) {
            $message = $message . ' - Quy Giáp';
            $type = 'qg';
        }

        if (strpos($srcMessage, ' La ') !== false) {
            $message = $message . ' - La Bàn';
            $type = 'lb';
        }

        if (strpos($srcMessage, ' Chu') !== false) {
            $message = $message . ' - Chu Sa';
            $type = 'cs';
        }

        if (strpos($srcMessage, ' Quyên') !== false) {
            $message = $message . ' - Quyên Bạch';
            $type = 'qb';
        }

        if (strpos($srcMessage, ' Lông') !== false) {
            $message = $message . ' - Lông Sói';
            $type = 'ls';
        }

        if (strpos($srcMessage, ' Gân') !== false) {
            $message = $message . ' - Gân Gà';
            $type = 'gg';
        }

        $showAllReward = Cache::get('show_all_reward', false);
        if ($showAllReward) {
            task_reward($message);
            return;
        }

        if ($type == 'tbd' || $type == 'tbdc' || $type == 'lb' || $type == 'qg') {
            task_reward($message);
        }
    }

    public function baiPhongThanThu(Account $account)
    {
        $bossId = 3; // Cùng Kỳ
        // $bossId = 5; // Hắc Huyết Ma Lang
        // $bossId = 16; // Thủy Ma Long
        if ($account->bang_phai == 'my-nhan') {
            $bossId = 16;
        }
        $this->getBaseCurl("https://tutien.net/account/bang_phai/than_thu/", $account->cookie, $account->proxy)
            ->withData([
                "btnThamHoi" => 1,
                "boss_id" => $bossId
            ])
            ->post();
    }

    /**
     * @param string $to
     * @param string $cookie
     * @param string $referer
     */
    private function getBaseCurl(string $to, string $cookie, Proxy $proxy, string $referer = '')
    {
        if (!$referer) {
            $referer = $to;
        }

        return Curl::to($to)
            ->withHeader('authority: tutien.net')
            ->withHeader('accept: */*')
            ->withHeader('sec-fetch-dest: empty')
            ->withHeader('x-requested-with: XMLHttpRequest')
            ->withHeader('user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.3990.0 Safari/537.36')
            ->withHeader('content-type: application/x-www-form-urlencoded; charset=UTF-8')
            ->withHeader('origin: https://tutien.net')
            ->withHeader('sec-fetch-site: same-origin')
            ->withHeader('sec-fetch-mode: cors')
            ->withHeader('referer: ' . $referer)
            ->withHeader('accept-language: en-US,en;q=0.9')
            ->withHeader($cookie)
            ->withProxy(
                $proxy->host,
                $proxy->port,
                $proxy->type,
                $proxy->username,
                $proxy->password
            );
    }

    private function handleProxyRequest(Account $account, Proxy $proxy, $response): bool
    {
        if (isset($response->error)) {
            $proxy->update(['failed_count' => $proxy->failed_count + 1]);
            $account->proxies()->detach();
            return false;
        }

        if (empty($headers)) {
            $proxy->update(['failed_count' => $proxy->failed_count + 1]);
            $account->proxies()->detach();
            return false;
        }

        if (empty($headers['set-cookie'])) {
            return false;
        }

        return true;
    }
}
