<?php

namespace App\Services;


use App\Account;
use App\AccountLog;
use App\CookieHelper;
use App\Jobs\NopDo;
use App\Jobs\NopKho;
use App\Jobs\DotPha;
use App\Jobs\UpdateAccount;
use App\Events\CanDanMessage;
use App\Services\AccountService;

use Illuminate\Support\Arr;
use Illuminate\Support\Str;
use Redis;

use Carbon\Carbon;
use voku\helper\HtmlDomParser;
use Ixudra\Curl\Facades\Curl;

class DotPhaService
{
    const TTD_EXP = 150;
    const TCD_EXP = 200;
    const BND_EXP = 300;
    const BAD_EXP = 600;
    const HND_EXP = 1200;
    const LTD_EXP = 2400;
    const DLD_EXP = 9600;
    const LTCP_EXP = 3000;
    const TLHP_EXP = 50000;

    const HOP_NGUYEN_DAN_EXP = 4800;
    const TL_TP_EXP = 80000;
    const TL_THP_EXP = 120000;
    const TL_CP_EXP = 170000;

    const ID_TTD = 9;
    const ID_TCD = 13;
    const ID_BND = 14;
    const ID_HND = 62;
    const ID_BAD = 40;
    const ID_PTD = 36;
    const ID_UTD = 22;
    const ID_LTCP = 76;
    const ID_LTD = 77;
    const ID_TLHP = 599;
    const ID_LTTHP = 61;
    const ID_CTD = 60;

    const ID_HOP_NGUYEN_DAN = 603;
    const ID_TL_TP = 600;
    const ID_TL_THP = 601;
    const ID_TL_CP = 602;
    const ID_DLD = 605;

    const ID_HKD = 10;
    const ID_DGT = 11;
    const ID_TLC = 17;
    const ID_THANH = 34;

    public $accountService;

    public function __construct(AccountService $service)
    {
        $this->accountService = $service;
    }

    public function canDan(Account $account, $danDuoc, $buff = [], $isDt = false)
    {
        $proxies = config('dp_proxies.list');
        $proxy = Arr::random($proxies);
        $response = Curl::to('https://tutien.net/account/tu_luyen/dot_pha')
            ->withHeader('authority: tutien.net')
            ->withHeader('cache-control: max-age=0')
            ->withHeader('dnt: 1')
            ->withHeader('upgrade-insecure-requests: 1')
            ->withHeader('user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
            ->withHeader('sec-fetch-dest: document')
            ->withHeader('accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9')
            ->withHeader('sec-fetch-site: none')
            ->withHeader('sec-fetch-mode: navigate')
            ->withHeader('sec-fetch-user: ?1')
            ->withHeader('accept-language: vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7,de;q=0.6,ja;q=0.5')
            ->withHeader($account->cookie)
            ->withProxy($proxy['host'], $proxy['port'], 'http://', $proxy['username'], $proxy['password'])
            ->withResponseHeaders()
            ->returnResponseObject()
            ->get();

        $content = $response->content;
        $headers = $response->headers;

        $html = HTMLDomParser::str_get_html($content);
        if (gettype($html) == 'boolean') {
            return;
        }

        $info = $html->find('.progress-bar');
        $infoText = $html->find('#content strong > span');
        if (count($info) === 0)  {
            // debug($account->toArray());
            return;
        }

        $progressText = count($infoText) ? $infoText[0]->plaintext : '';
        $progressNumber = $info[0]->plaintext;

        $progressNumber = str_replace(")", "", $progressNumber);
        $progressNumber = explode("(", $progressNumber)[1];
        $progresses = explode("/", $progressNumber);

        $maxExp = intval($progresses[1]);
        $currentExp = intval($progresses[0]);
        $missingExp = $maxExp - $currentExp;
        $ok = $this->chuyenDanDuoc($account, $danDuoc, $missingExp);

        if ($ok) {
            $this->prepareDotPha($account);
            sleep(1);
            $this->chuyenBuff($account, $buff);
            sleep(1);
            $this->dotPha($account, $buff, $isDt);
        } else {
            app(AccountService::class)->getAccountInfo($account, $account->cookie);
        }
    }

    public function chuyenBuff($account, $buff)
    {
        $phuTro = $buff['vatphamphutro'];
        if (count($phuTro)) {
            CanDanMessage::dispatch($account, 'Chuyển đồ buff');
        }
        for ($i = 0; $i < count($phuTro); $i ++) {
            $this->accountService->chuyenDo($account, $phuTro[$i], 1);
        }
    }

    public function chuyenDanDuoc($account, $danDuoc, $exp)
    {
        $amount = 0;
        $danDuocId = self::ID_TTD;
        $amount10 = 0;
        switch ($danDuoc) {
            case 'ttd':
                $amount = (int) (ceil($exp / self::TTD_EXP));
                $danDuocId = self::ID_TTD;
                break;
            case 'tcd':
                $amount = (int) (ceil($exp / self::TCD_EXP));
                $danDuocId = self::ID_TCD;
                break;
            case 'bnd':
                $amount = (int) (ceil($exp / self::BND_EXP));
                $danDuocId = self::ID_BND;
                break;
            case 'bad':
                $amount = (int) (ceil($exp / self::BAD_EXP));
                $danDuocId = self::ID_BAD;
                break;
                break;
            case 'hnd':
                $amount = (int) (ceil($exp / self::HND_EXP));
                $danDuocId = self::ID_HND;
                break;
            case 'ltd':
                $amount = (int) (ceil($exp / self::LTD_EXP));
                $danDuocId = self::ID_LTD;
                break;
            case 'ltcp':
                $amount = 1;
                $danDuocId = self::ID_LTCP;
                break;
            case 'tlhp':
                $amount = 1;
                $danDuocId = self::ID_TLHP;
                break;
            case 'tltp':
                $amount = 1;
                $danDuocId = self::ID_TL_TP;
                break;
            case 'tlthp':
                $amount = 1;
                $danDuocId = self::ID_TL_THP;
                break;
            case 'tlcp':
                $amount = 1;
                $danDuocId = self::ID_TL_CP;
                break;
            case 'hnd2':
                $amount = (int) (ceil($exp / self::HOP_NGUYEN_DAN_EXP));
                $danDuocId = self::ID_HOP_NGUYEN_DAN;
                break;
            case 'dld':
                $amount = (int) (ceil($exp / self::DLD_EXP));
                $danDuocId = self::ID_DLD;
                break;
        }

        if ($danDuoc == 'ltcp') {
            $this->accountService->chuyenDo($account, self::ID_LTCP, 1);
            sleep(1);
            $this->canDanDuoc($account, self::ID_LTCP, 1);
            $hndExp = $exp - 30000;
            $amount = (int) (ceil($hndExp / 1200));
            $danDuocId = self::ID_HND;
        } else if ($danDuoc == 'tlhp') {
            $this->accountService->chuyenDo($account, self::ID_TLHP, 1);
            sleep(1);
            $this->canDanDuoc($account, self::ID_TLHP, 1);
            $missingExp = $exp - 50000;
            if ($missingExp > 0) {
                CanDanMessage::dispatch($account, 'Thiếu EXP, vui lòng cắn tiếp!');
                return false;
            }
            return true;
        } else if ($danDuoc == 'tltp') {
            $this->accountService->chuyenDo($account, self::ID_TL_TP, 1);
            sleep(1);
            $this->canDanDuoc($account, self::ID_TL_TP, 1);
            $missingExp = $exp - 80000;
            if ($missingExp > 0) {
                CanDanMessage::dispatch($account, 'Thiếu EXP, vui lòng cắn tiếp!');
                return false;
            }
            return true;
        } else if ($danDuoc == 'tlthp') {
            $this->accountService->chuyenDo($account, self::ID_TL_THP, 1);
            sleep(1);
            $this->canDanDuoc($account, self::ID_TL_THP, 1);
            $missingExp = $exp - 120000;
            if ($missingExp > 0) {
                CanDanMessage::dispatch($account, 'Thiếu EXP, vui lòng cắn tiếp!');
                return false;
            }
            return true;
        } else if ($danDuoc == 'tlcp') {
            $this->accountService->chuyenDo($account, self::ID_TL_CP, 1);
            sleep(1);
            $this->canDanDuoc($account, self::ID_TL_CP, 1);
            $missingExp = $exp - 170000;
            if ($missingExp > 0) {
                CanDanMessage::dispatch($account, 'Thiếu EXP, vui lòng cắn tiếp!');
                return false;
            }
            return true;
        }

        $this->accountService->chuyenDo($account, $danDuocId, $amount);
        $amount10 = (int) ($amount / 10);
        $amount1 = $amount % 10;
        for ($i = 0; $i < $amount10; $i++) {
            $this->canDanDuoc($account, $danDuocId, 10);
            sleep(2);
        }

        for ($i = 0; $i < $amount1; $i++) {
            $this->canDanDuoc($account, $danDuocId, 1);
            sleep(2);
        }

        return true;
    }

    public function canDanDuoc($account, $danDuocId, $amount = 1)
    {
        $proxies = config('dp_proxies.list');
        $proxy = Arr::random($proxies);
        $response = Curl::to('https://tutien.net/account/vat_pham/')
            ->withHeader('authority: tutien.net')
            ->withHeader('sec-ch-ua: " Not A;Brand";v="99", "Chromium";v="96", "Google Chrome";v="96"')
            ->withHeader('dnt: 1')
            ->withHeader('sec-ch-ua-mobile: ?0')
            ->withHeader('user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36')
            ->withHeader('content-type: application/x-www-form-urlencoded; charset=UTF-8')
            ->withHeader('accept: */*')
            ->withHeader('x-requested-with: XMLHttpRequest')
            ->withHeader('sec-ch-ua-platform: "macOS"')
            ->withHeader('origin: https://tutien.net')
            ->withHeader('sec-fetch-site: same-origin')
            ->withHeader('sec-fetch-mode: cors')
            ->withHeader('sec-fetch-dest: empty')
            ->withHeader('referer: https://tutien.net/account/vat_pham/')
            ->withHeader('accept-language: en-US,en;q=0.9,vi;q=0.8')
            ->withHeader($account->cookie)
            ->withProxy($proxy['host'], $proxy['port'], 'http://', $proxy['username'], $proxy['password'])
            ->withData([
                'btnTangExpBac' => 1,
                'items' => $danDuocId,
                'txtSoLuong' => $amount
            ])
            ->withResponseHeaders()
            ->returnResponseObject()
            ->post();
        $content = $response->content;
        $content = json_decode($content, true);


        if (!empty($content['error'])) {
            $message = $content['error'];
        } else {
            $message = $content['data'];
        }

        CanDanMessage::dispatch($account, $message);
        // $message = json_decode(sprintf('"%s"', $content['data']));
        // CanDanMessage::dispatch($account, $message);
    }

    public function prepareDotPha($account)
    {
        $service = app(AccountService::class);
	    $progress = $account->progress;

	    if (strpos($progress, "Viên Mãn") !== false) {
            $this->accountService->taoNhanVat($account);
            CanDanMessage::dispatch($account, 'Tạo Nhân vật');
            sleep(1);
            $this->accountService->nopCongPhap($account);
	        CanDanMessage::dispatch($account, 'Cho công pháp vào hành trang');
	    }

        if (strpos($progress, "Luyện Khí Viên Mãn") !== false) {
            CanDanMessage::dispatch($account, 'Chuyển trúc cơ đan');
            $this->accountService->chuyenDo($account, self::ID_TCD, 1);
        } else if (strpos($progress, "Trúc Cơ Viên Mãn") !== false) {
            CanDanMessage::dispatch($account, 'Chuyển Uẩn thiên đan');
            $this->accountService->chuyenDo($account, self::ID_UTD, 1);
        } else if (strpos($progress, "Kim Đan Viên Mãn") !== false) {
            CanDanMessage::dispatch($account, 'Chuyển phá thiên đan');
            $this->accountService->chuyenDo($account, self::ID_PTD, 1);
        } else if (strpos($progress, "Nguyên Anh Viên Mãn") !== false) {
            CanDanMessage::dispatch($account, 'Chuyển Cố Thần Đan + Linh Thạch THP');
            $this->accountService->chuyenDo($account, self::ID_CTD, 1);
            sleep(1);
            $this->accountService->chuyenDo($account, self::ID_LTTHP, 1);
        } else {
            $this->accountService->checkRequireItems($account);
        }
    }

    public function rutCongPhap(Account $account)
    {
        $keys = Redis::keys($account->account_id . "_cp_*");
        foreach ($keys as $key) {
            $id = str_replace($account->account_id . "_cp_", "", $key);
            $amount = Redis::get($key) || 0;
            $this->accountService->rutHanhTrang($account, $id, $amount);
        }
    }

    public function dotPha(Account $account, $buff = [], $isDt = false)
    {
        $proxies = config('dp_proxies.list');
        $proxy = Arr::random($proxies);
        $buff['btnDotPha'] = 1;
        if ($isDt) {
            $buff['tiledotpha'] = 0;
            $response = Curl::to('https://tutien.net/account/bang_phai/dong_thien')
                ->withHeader('authority: truyencv.com')
                ->withHeader('accept: */*')
                ->withHeader('sec-fetch-dest: empty')
                ->withHeader('x-requested-with: XMLHttpRequest')
                ->withHeader('user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.3990.0 Safari/537.36')
                ->withHeader('content-type: application/x-www-form-urlencoded; charset=UTF-8')
                ->withHeader('origin: https://tutien.net')
                ->withHeader('sec-fetch-site: same-origin')
                ->withHeader('sec-fetch-mode: cors')
                ->withHeader('referer: https://tutien.net/account/bang_phai/dong_thien')
                ->withHeader('accept-language: en-US,en;q=0.9')
                ->withHeader($account->cookie)
                ->withData($buff)
                ->withProxy($proxy['host'], $proxy['port'], 'http://', $proxy['username'], $proxy['password'])
                ->withResponseHeaders()
                ->returnResponseObject()
                ->post();
        } else {
            $response = Curl::to('https://tutien.net/account/tu_luyen/dot_pha')
                ->withHeader('authority: truyencv.com')
                ->withHeader('accept: */*')
                ->withHeader('sec-fetch-dest: empty')
                ->withHeader('x-requested-with: XMLHttpRequest')
                ->withHeader('user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.3990.0 Safari/537.36')
                ->withHeader('content-type: application/x-www-form-urlencoded; charset=UTF-8')
                ->withHeader('origin: https://tutien.net')
                ->withHeader('sec-fetch-site: same-origin')
                ->withHeader('sec-fetch-mode: cors')
                ->withHeader('referer: https://tutien.net/account/tu_luyen/dot_pha')
                ->withHeader('accept-language: en-US,en;q=0.9')
                ->withHeader($account->cookie)
                ->withData($buff)
                ->withProxy($proxy['host'], $proxy['port'], 'http://', $proxy['username'], $proxy['password'])
                ->withResponseHeaders()
                ->returnResponseObject()
                ->post();
        }

        $content = $response->content;
        if ($content == 1) {
            CanDanMessage::dispatch($account, 'Đột phá thành công');
        } else {
            if ($content != '') {
                CanDanMessage::dispatch($account, 'Tạch!');
            } else {
                CanDanMessage::dispatch($account, 'Có lỗi xảy ra!');
            }
        }

        if (strpos($account->progress, 'Viên Mãn') !== false) {
            CanDanMessage::dispatch($account, 'Lấy công pháp từ hành trang');
            sleep(1);
            $this->rutCongPhap($account);
        }
        app(AccountService::class)->getAccountInfo($account, $account->cookie);
    }
}
