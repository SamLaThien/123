#!/bin/sh
python /home/tcv.py /home/account.cfg