import {fetchItemCh, redirectBaoKho} from "../modules/bao-kho.js";

redirectBaoKho(null).then(r => console.log(r));
