const VU_KHI = 1;
const KHAI_GIAP = 2;
const LUYEN_KHI_SU = [
    {
        id: 317357,
        cookie: 'USER=km7mszm5uJ%2FP%3AGG4zwJKLlHDRrxoREzZ%2FegjDOZZPsZLza6jwYmGjH8Aw',
        cap: 9,
        type: KHAI_GIAP,
    },
    {
        id: 271757,
        cookie: 'USER=nMnNM9ITEmjA%3AU00e6CQToJ0t7BFEWZKmriWAQEM9z%2BksNmZ%2FHEZ%2FclSt',
        cap: 9,
        type: KHAI_GIAP,
    }
]

const KHAI_GIAPS = [
    {
        id: 0,
        name: 'Thuẫn',
    },
    {
        id: 1,
        name: 'Khôi',
    }, {
        id: 2,
        name: 'Giáp',
    }, {
        id: 3,
        name: 'Thủ Sáo',
    }, {
        id: 4,
        name: 'Yêu Đái',
    }, {
        id: 5,
        name: 'Trang',
    }, {
        id: 6,
        name: 'Ngoa',
    }
];
