export const BANK_COOKIE = "USER=F7y5pT7ozVrv%3A9G9c4w7WuZyAzoM7Annc7XcXo41Jtp%2BtucoTQM7kWPxY";

export const CM_COOKIE = "PHPSESSID=q17bmle2un1jarvqbdc1k45lm5; USER=F7y5pT7ozVrv%3A9G9c4w7WuZyAzoM7Annc7XcXo41Jtp%2BtucoTQM7kWPxY; reada=15";
export const BOT_ID = "";
export const BOT_URL = "";
export const CHUYEN_DO_IDS = [300200,381664];
export const ADMIN = [300200,381664];
export const MOVE_IDS = [608485,132301,150858];
export const DUYET_IDS = [230983,308555,608485,230833];
export const KICK_IDS = [];

// Dùng cho lệnh move
export const USER_COOKIES = [
    {
        user_id: 702897,
        cookie: 'USER=CY76ajKCZtuR%3AIaXbqH9ekTnQpy3ctF3pQ0jrYZhZ%2F8ANx%2BRhdkj6SOFE'
    },
    {
        user_id: 636888,
        cookie: 'USER=mIHWuloAvyRN%3Avrmj8HYO%2BttSG%2BqqQixltS9c6i%2BLBOs%2BX5VcMh0XPv0R'
    },
    {
        user_id: 744444,
        cookie: 'USER=%2BhMmoz9mZrcV%3APnmtkIB1EnjTwsZJqUEzBaJ3q7BGXok8YRDzX8xlTenC'
    },
];

// Log nop do
export const ITEM_EXPIRE_IN = 30 * 60; // 30p
export const INTERVAL_CHECK_LOG = 10;

// QUEUE
export const QUEUE_MAX_RETRY = 5;

// Chuyen Do
export const CD_PRICE = 0;

// Chuyen bac
export const MAX_CHUYEN_BAC = 200000;

// SHOP
export const SHOP = true;

// BANK
export const BANK_ID = '456789';

// PERMISSIONS
export const PERMISSIONS = [
    'chuyendo',
    'chuc',
    'clear',
    'ch',
    'dong',
    'duyet',
    'kick',
    'ban',
    'info',
    'dong'
];

export default {
    BANK_COOKIE,
    CM_COOKIE,
    BOT_ID,
    BOT_URL
}
