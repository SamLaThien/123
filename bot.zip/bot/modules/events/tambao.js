import {chat, getItem, setItem} from '../../helper.js';
import {updateRuong} from "../chuyen-do.js";

const getRndInteger = (min, max) => {
  return Math.floor(Math.random() * (max - min) ) + min;
}


