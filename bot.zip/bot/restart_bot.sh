#!/bin/bash
/usr/bin/pm2 restart 6
